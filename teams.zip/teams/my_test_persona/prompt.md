# Default Prompt

This is the default prompt for your persona.
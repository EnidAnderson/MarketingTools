# Change Request Template

- request_id: `CR-<TEAM>-0000` (example: `CR-RED-0011`)
- source_team: `blue|red|green|black|white|grey`
- priority: `P0|P1|P2`
- statement:
- acceptance_criteria:
- constraints:
- evidence_refs:
- target_owner: `qa_fixer`
